<h4 class="text-center animated zoomIn" id="featured-products-heading">About Us</h4>
<div class="text-center">
	<div class="container-fluid" id="Index-Main-Container">
		<div class="row" id="about-us">
			<div class="col-xs-12 col-sm-12 col-md-12 col-lg-12">
				<p>PT SHOPPING is</p>
			</div>
		</div>
	</div>
</div>
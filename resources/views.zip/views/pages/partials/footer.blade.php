<footer class="page-footer elegant-color" if="footer" id="contact">
    <div class="footer-copyright">
        <div class="container">
            <div class="col-md-10 col-md-offset-1 text-center"><a href="#" target="_blank">© 2016</a></div>
        </div>
    </div>
</footer>
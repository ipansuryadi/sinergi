<div id="tf-home-m" class="text-center">
    <div class="overlay">
        <div class="content">
            <h1><strong><span class="color">{{config('label')->website_title}}</span></strong></h1>
            <p class="lead">{{config('label')->website_description}}</p>
            <a href="#featured-products-heading" class="btn btn-border-primary waves-effect" id="arrow-btn"><i class="fa fa-arrow-down fa-2x" aria-hidden="true"></i></a>
        </div>
    </div>
</div>